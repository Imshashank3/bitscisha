package com.bitscisha.app.ui.theme

import androidx.compose.ui.graphics.Color

// Primary colors from website
val PrimaryBg = Color(0xFF0B1728)
val SecondaryBg = Color(0xFF05101E)
val PrimaryAccent = Color(0xFF00B2CA)
val SecondaryAccent = Color(0xFFFF6B35)
val TertiaryAccent = Color(0xFF9B5DE5)
val QuaternaryAccent = Color(0xFFFFCC00)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFE0E0E0)
