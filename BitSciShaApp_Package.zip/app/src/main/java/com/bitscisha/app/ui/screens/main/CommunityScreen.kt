package com.bitscisha.app.ui.screens.main

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Send
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.bitscisha.app.R
import com.bitscisha.app.ui.components.CosmicBackground
import com.bitscisha.app.ui.theme.PrimaryAccent
import com.bitscisha.app.ui.theme.SecondaryBg

@Composable
fun CommunityScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colors.background)
    ) {
        // Background
        CosmicBackground()
        
        // Content
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            item {
                Text(
                    text = stringResource(R.string.join_community),
                    style = MaterialTheme.typography.h4,
                    color = MaterialTheme.colors.onBackground
                )
                
                Spacer(modifier = Modifier.height(24.dp))
                
                // Social links
                SocialLinks()
                
                Spacer(modifier = Modifier.height(32.dp))
                
                // Newsletter
                NewsletterSection()
            }
        }
    }
}

@Composable
fun SocialLinks() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        backgroundColor = SecondaryBg.copy(alpha = 0.8f),
        elevation = 4.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SocialLinkItem(
                platform = "YouTube",
                icon = R.drawable.ic_youtube,
                color = Color(0xFFFF0000),
                onClick = { /* TODO: Open YouTube link */ }
            )
            
            SocialLinkItem(
                platform = "Discord",
                icon = R.drawable.ic_discord,
                color = Color(0xFF5865F2),
                onClick = { /* TODO: Open Discord link */ }
            )
            
            SocialLinkItem(
                platform = "Twitter (X)",
                icon = R.drawable.ic_twitter,
                color = Color(0xFF1DA1F2),
                onClick = { /* TODO: Open Twitter link */ }
            )
            
            SocialLinkItem(
                platform = "Instagram",
                icon = R.drawable.ic_instagram,
                color = Color(0xFFE1306C),
                onClick = { /* TODO: Open Instagram link */ }
            )
            
            SocialLinkItem(
                platform = "Linktree",
                icon = R.drawable.ic_linktree,
                color = Color(0xFF39E09B),
                onClick = { /* TODO: Open Linktree link */ }
            )
            
            SocialLinkItem(
                platform = "Snapchat",
                icon = R.drawable.ic_snapchat,
                color = Color(0xFFFFFC00),
                onClick = { /* TODO: Open Snapchat link */ }
            )
        }
    }
}

@Composable
fun SocialLinkItem(
    platform: String,
    icon: Int,
    color: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.2f))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            painter = painterResource(id = icon),
            contentDescription = platform,
            tint = color,
            modifier = Modifier.size(24.dp)
        )
        
        Spacer(modifier = Modifier.width(16.dp))
        
        Text(
            text = platform,
            style = MaterialTheme.typography.subtitle1,
            color = MaterialTheme.colors.onBackground
        )
        
        Spacer(modifier = Modifier.weight(1f))
        
        Icon(
            painter = painterResource(id = R.drawable.ic_arrow_right),
            contentDescription = null,
            tint = MaterialTheme.colors.onBackground.copy(alpha = 0.7f),
            modifier = Modifier.size(16.dp)
        )
    }
}

@Composable
fun NewsletterSection() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        backgroundColor = SecondaryBg.copy(alpha = 0.8f),
        elevation = 4.dp
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = stringResource(R.string.subscribe_newsletter),
                style = MaterialTheme.typography.h5,
                textAlign = TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = stringResource(R.string.get_updates),
                style = MaterialTheme.typography.body1,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colors.onBackground.copy(alpha = 0.7f)
            )
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Email input
            var email by remember { mutableStateOf("") }
            var isSubscribing by remember { mutableStateOf(false) }
            
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text(stringResource(R.string.email)) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Email,
                        contentDescription = null
                    )
                },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email,
                    imeAction = ImeAction.Done
                ),
                modifier = Modifier.fillMaxWidth()
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Subscribe button
            Button(
                onClick = {
                    isSubscribing = true
                    // TODO: Implement newsletter subscription
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                enabled = !isSubscribing && email.isNotEmpty()
            ) {
                if (isSubscribing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(24.dp),
                        color = MaterialTheme.colors.onPrimary,
                        strokeWidth = 2.dp
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    Text(text = stringResource(R.string.subscribe))
                }
            }
        }
    }
}
