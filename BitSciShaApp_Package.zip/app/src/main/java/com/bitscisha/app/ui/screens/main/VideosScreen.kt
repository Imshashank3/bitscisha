package com.bitscisha.app.ui.screens.main

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.bitscisha.app.R
import com.bitscisha.app.ui.components.CosmicBackground
import com.bitscisha.app.ui.theme.PrimaryAccent
import com.bitscisha.app.ui.theme.SecondaryAccent
import com.bitscisha.app.ui.theme.SecondaryBg

@Composable
fun VideosScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colors.background)
    ) {
        // Background
        CosmicBackground()
        
        // Content
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            item {
                Text(
                    text = stringResource(R.string.featured_videos),
                    style = MaterialTheme.typography.h4,
                    color = MaterialTheme.colors.onBackground
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Category filters
                CategoryFilters()
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Featured videos carousel
                FeaturedVideosCarousel()
            }
            
            item {
                Spacer(modifier = Modifier.height(8.dp))
                
                // Video grid
                Text(
                    text = "All Videos",
                    style = MaterialTheme.typography.h5,
                    color = MaterialTheme.colors.onBackground
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                VideoGrid()
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // View all button
                OutlinedButton(
                    onClick = { /* TODO: Navigate to YouTube channel */ },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = PrimaryAccent
                    )
                ) {
                    Text(text = stringResource(R.string.view_all_videos))
                }
            }
        }
    }
}

@Composable
fun CategoryFilters() {
    val categories = listOf(
        stringResource(R.string.fresh_uploads),
        stringResource(R.string.upcoming),
        stringResource(R.string.like_share_subscribe)
    )
    
    var selectedCategory by remember { mutableStateOf(categories[0]) }
    
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(categories) { category ->
            FilterChip(
                selected = selectedCategory == category,
                onClick = { selectedCategory = category },
                category = category
            )
        }
    }
}

@Composable
fun FilterChip(
    selected: Boolean,
    onClick: () -> Unit,
    category: String
) {
    val backgroundColor = if (selected) PrimaryAccent else SecondaryBg.copy(alpha = 0.7f)
    val contentColor = if (selected) Color.Black else MaterialTheme.colors.onBackground
    
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(backgroundColor)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = category,
            color = contentColor,
            style = MaterialTheme.typography.body2.copy(
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
            )
        )
    }
}

@Composable
fun FeaturedVideosCarousel() {
    val featuredVideos = listOf(
        VideoItem(
            id = "1",
            title = "How RAW Caught INDIA'S Greatest Traitor",
            description = "Story about Ravindra kaushik, a RAW agent.",
            thumbnailResId = R.drawable.video_thumbnail_1
        ),
        VideoItem(
            id = "2",
            title = "Inside Balochistan: History, Struggle and Silence",
            description = "(Upcoming).",
            thumbnailResId = R.drawable.video_thumbnail_2
        ),
        VideoItem(
            id = "3",
            title = "Terrestrial Bodies: Earth and Beyond",
            description = "From cratered moons and rust-hued Martian canyons to Earth's ocean-kissed shores (Upcoming).",
            thumbnailResId = R.drawable.video_thumbnail_4
        )
    )
    
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(featuredVideos) { video ->
            FeaturedVideoCard(video = video)
        }
    }
}

@Composable
fun FeaturedVideoCard(video: VideoItem) {
    Card(
        modifier = Modifier
            .width(280.dp)
            .clickable { /* TODO: Navigate to video detail */ },
        shape = RoundedCornerShape(12.dp),
        backgroundColor = SecondaryBg.copy(alpha = 0.7f),
        elevation = 4.dp
    ) {
        Column {
            // Thumbnail with play button overlay
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
            ) {
                Image(
                    painter = painterResource(id = video.thumbnailResId),
                    contentDescription = video.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                
                // Play button overlay
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .align(Alignment.Center)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color.Black.copy(alpha = 0.7f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Play",
                        tint = Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
            
            // Video info
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = video.title,
                    style = MaterialTheme.typography.h6,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = video.description,
                    style = MaterialTheme.typography.body2,
                    color = MaterialTheme.colors.onBackground.copy(alpha = 0.7f),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun VideoGrid() {
    val videos = listOf(
        VideoItem(
            id = "1",
            title = "How RAW Caught INDIA'S Greatest Traitor",
            description = "Story about Ravindra kaushik, a RAW agent.",
            thumbnailResId = R.drawable.video_thumbnail_1
        ),
        VideoItem(
            id = "2",
            title = "Inside Balochistan: History, Struggle and Silence",
            description = "(Upcoming).",
            thumbnailResId = R.drawable.video_thumbnail_2
        ),
        VideoItem(
            id = "3",
            title = "Terrestrial Bodies: Earth and Beyond",
            description = "From cratered moons and rust-hued Martian canyons to Earth's ocean-kissed shores (Upcoming).",
            thumbnailResId = R.drawable.video_thumbnail_4
        ),
        VideoItem(
            id = "4",
            title = "New Video Coming Soon",
            description = "Stay tuned for more exciting content.",
            thumbnailResId = R.drawable.video_thumbnail_5
        )
    )
    
    Column(
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        videos.forEach { video ->
            VideoListItem(video = video)
        }
    }
}

@Composable
fun VideoListItem(video: VideoItem) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { /* TODO: Navigate to video detail */ },
        shape = RoundedCornerShape(12.dp),
        backgroundColor = SecondaryBg.copy(alpha = 0.7f),
        elevation = 4.dp
    ) {
        Row(
            modifier = Modifier.height(100.dp)
        ) {
            // Thumbnail
            Box(
                modifier = Modifier
                    .width(140.dp)
                    .fillMaxHeight()
            ) {
                Image(
                    painter = painterResource(id = video.thumbnailResId),
                    contentDescription = video.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                
                // Play button overlay
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .align(Alignment.Center)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color.Black.copy(alpha = 0.7f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Play",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
            
            // Video info
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = video.title,
                    style = MaterialTheme.typography.subtitle1,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = video.description,
                    style = MaterialTheme.typography.body2,
                    color = MaterialTheme.colors.onBackground.copy(alpha = 0.7f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

data class VideoItem(
    val id: String,
    val title: String,
    val description: String,
    val thumbnailResId: Int
)
