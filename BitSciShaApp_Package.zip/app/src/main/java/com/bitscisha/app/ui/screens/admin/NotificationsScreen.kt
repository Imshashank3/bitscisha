package com.bitscisha.app.ui.screens.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.bitscisha.app.data.admin.AdminViewModel
import com.bitscisha.app.data.admin.NotificationData
import com.bitscisha.app.ui.components.CosmicBackground
import com.bitscisha.app.ui.theme.PrimaryAccent
import com.bitscisha.app.ui.theme.SecondaryBg
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun NotificationsScreen(
    adminViewModel: AdminViewModel,
    onNavigateBack: () -> Unit
) {
    val notifications by adminViewModel.notifications.collectAsState(initial = emptyList())
    
    LaunchedEffect(key1 = true) {
        adminViewModel.loadNotifications()
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colors.background)
    ) {
        // Background
        CosmicBackground()
        
        // Content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onNavigateBack
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = MaterialTheme.colors.onBackground
                    )
                }
                
                Text(
                    text = "Notifications",
                    style = MaterialTheme.typography.h5,
                    color = MaterialTheme.colors.onBackground
                )
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // Notifications list
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                backgroundColor = SecondaryBg.copy(alpha = 0.8f),
                elevation = 4.dp
            ) {
                if (notifications.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No notifications",
                            style = MaterialTheme.typography.body1,
                            color = MaterialTheme.colors.onBackground.copy(alpha = 0.7f)
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 500.dp)
                    ) {
                        items(notifications) { notification ->
                            NotificationItem(
                                notification = notification,
                                onMarkAsRead = { adminViewModel.markNotificationAsRead(notification.id) }
                            )
                            
                            Divider(color = MaterialTheme.colors.onSurface.copy(alpha = 0.1f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NotificationItem(
    notification: NotificationData,
    onMarkAsRead: () -> Unit
) {
    val dateFormat = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
    val notificationDate = dateFormat.format(Date(notification.timestamp))
    
    var showMarkAsReadConfirmation by remember { mutableStateOf(false) }
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .background(
                if (!notification.read) 
                    MaterialTheme.colors.primary.copy(alpha = 0.1f) 
                else 
                    Color.Transparent
            ),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Notification icon
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(
                    if (!notification.read) 
                        PrimaryAccent.copy(alpha = 0.2f) 
                    else 
                        MaterialTheme.colors.onBackground.copy(alpha = 0.1f)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = when (notification.type) {
                    "new_user" -> Icons.Default.PersonAdd
                    else -> Icons.Default.Notifications
                },
                contentDescription = null,
                tint = if (!notification.read) PrimaryAccent else MaterialTheme.colors.onBackground.copy(alpha = 0.5f)
            )
        }
        
        Spacer(modifier = Modifier.width(16.dp))
        
        // Notification content
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = when (notification.type) {
                    "new_user" -> "New User Registration"
                    else -> "Notification"
                },
                style = MaterialTheme.typography.subtitle1.copy(
                    fontWeight = if (!notification.read) FontWeight.Bold else FontWeight.Normal
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Text(
                text = when (notification.type) {
                    "new_user" -> "${notification.userName} (${notification.userEmail}) has registered"
                    else -> "You have a new notification"
                },
                style = MaterialTheme.typography.body2,
                color = MaterialTheme.colors.onBackground.copy(alpha = 0.7f),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            
            Spacer(modifier = Modifier.height(4.dp))
            
            Text(
                text = notificationDate,
                style = MaterialTheme.typography.caption,
                color = MaterialTheme.colors.onBackground.copy(alpha = 0.5f)
            )
        }
        
        // Mark as read button (only for unread notifications)
        if (!notification.read) {
            IconButton(
                onClick = { showMarkAsReadConfirmation = true }
            ) {
                Icon(
                    imageVector = Icons.Default.MarkEmailRead,
                    contentDescription = "Mark as read",
                    tint = PrimaryAccent
                )
            }
        }
    }
    
    // Mark as read confirmation dialog
    if (showMarkAsReadConfirmation) {
        AlertDialog(
            onDismissRequest = { showMarkAsReadConfirmation = false },
            title = { Text("Mark as Read") },
            text = { Text("Mark this notification as read?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onMarkAsRead()
                        showMarkAsReadConfirmation = false
                    }
                ) {
                    Text("Yes")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showMarkAsReadConfirmation = false }
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}
