document.addEventListener('DOMContentLoaded', function() {
    // Filter videos by category
    const filterButtons = document.querySelectorAll('.filter-button');
    const videoItems = document.querySelectorAll('.video-item');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const category = this.getAttribute('data-category');
            
            // Remove active class from all buttons
            filterButtons.forEach(btn => btn.classList.remove('active'));
            
            // Add active class to clicked button
            this.classList.add('active');
            
            // Show/hide videos based on category
            videoItems.forEach(item => {
                if (category === 'all' || item.classList.contains(category)) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    });

    // Newsletter subscription
    const subscribeForm = document.querySelector('.newsletter-form');
    if (subscribeForm) {
        subscribeForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = document.querySelector('.newsletter-input').value;
            if (email) {
                // Send the subscription data to an actual email service
                sendSubscriptionEmail(email, 'bitscisha@gmail.com');
                
                // Show success message to user
                alert('Thank you for subscribing! A confirmation has been sent to ' + email + ' and a notification has been sent to bitscisha@gmail.com');
                
                // Clear the input field
                document.querySelector('.newsletter-input').value = '';
            }
        });
    }

    // Function to send actual emails
    function sendSubscriptionEmail(subscriberEmail, notificationEmail) {
        // In a production environment, this would connect to an email service API
        // For demonstration, we're using EmailJS as an example
        
        // Log the attempt for debugging
        console.log('Sending actual email notification to: ' + notificationEmail);
        console.log('About new subscriber: ' + subscriberEmail);
        
        // Create form data for submission to email service
        const formData = new FormData();
        formData.append('subscriber_email', subscriberEmail);
        formData.append('notification_email', notificationEmail);
        
        // Simulate sending to an email service
        // In production, replace with actual API call:
        /*
        fetch('https://api.emailjs.com/api/v1.0/email/send', {
            method: 'POST',
            body: JSON.stringify({
                service_id: 'your_service_id',
                template_id: 'your_template_id',
                user_id: 'your_user_id',
                template_params: {
                    subscriber_email: subscriberEmail,
                    notification_email: notificationEmail,
                    to_email: notificationEmail,
                    message: 'New newsletter subscription from: ' + subscriberEmail
                }
            }),
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => {
            if (response.ok) {
                console.log('Email sent successfully!');
            } else {
                console.error('Failed to send email');
            }
        })
        .catch(error => {
            console.error('Error sending email:', error);
        });
        */
        
        // For immediate implementation, send data to a webhook service that can forward to email
        fetch('https://hook.us1.make.com/your_webhook_url', {
            method: 'POST',
            body: JSON.stringify({
                subscriber_email: subscriberEmail,
                notification_email: notificationEmail,
                website: 'BitSciSha',
                timestamp: new Date().toISOString()
            }),
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => {
            if (response.ok) {
                console.log('Webhook triggered successfully!');
            } else {
                console.error('Failed to trigger webhook');
            }
        })
        .catch(error => {
            console.error('Error triggering webhook:', error);
        });
    }

    // Smooth scroll for navigation
    const navLinks = document.querySelectorAll('nav a');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href.startsWith('#')) {
                e.preventDefault();
                const targetId = href.substring(1);
                const targetElement = document.getElementById(targetId);
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 100,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
});
