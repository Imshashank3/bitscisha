package com.bitscisha.app.data.auth

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AuthViewModel @Inject constructor(
    private val authRepository: AuthRepository
) {
    // Authentication state
    private val _authState = MutableStateFlow<AuthState>(AuthState.Initial)
    val authState: StateFlow<AuthState> = _authState
    
    // Current user
    private val _currentUser = MutableLiveData<FirebaseUser?>()
    val currentUser: LiveData<FirebaseUser?> = _currentUser
    
    init {
        // Initialize current user
        _currentUser.value = authRepository.currentUser
        
        // Set initial auth state
        if (authRepository.isUserLoggedIn()) {
            _authState.value = AuthState.Authenticated(authRepository.currentUser!!)
        } else {
            _authState.value = AuthState.Unauthenticated
        }
    }
    
    // Email/Password Sign In
    suspend fun signInWithEmailPassword(email: String, password: String) {
        _authState.value = AuthState.Loading
        
        authRepository.signInWithEmailPassword(email, password)
            .onSuccess { user ->
                _currentUser.value = user
                _authState.value = AuthState.Authenticated(user)
            }
            .onFailure { exception ->
                _authState.value = AuthState.Error(exception.message ?: "Authentication failed")
            }
    }
    
    // Email/Password Registration
    suspend fun registerWithEmailPassword(email: String, password: String, name: String) {
        _authState.value = AuthState.Loading
        
        authRepository.registerWithEmailPassword(email, password, name)
            .onSuccess { user ->
                _currentUser.value = user
                _authState.value = AuthState.Authenticated(user)
            }
            .onFailure { exception ->
                _authState.value = AuthState.Error(exception.message ?: "Registration failed")
            }
    }
    
    // Google Sign In
    suspend fun signInWithGoogle(idToken: String) {
        _authState.value = AuthState.Loading
        
        authRepository.signInWithGoogle(idToken)
            .onSuccess { user ->
                _currentUser.value = user
                _authState.value = AuthState.Authenticated(user)
            }
            .onFailure { exception ->
                _authState.value = AuthState.Error(exception.message ?: "Google authentication failed")
            }
    }
    
    // Facebook Sign In
    suspend fun signInWithFacebook(token: String) {
        _authState.value = AuthState.Loading
        
        authRepository.signInWithFacebook(token)
            .onSuccess { user ->
                _currentUser.value = user
                _authState.value = AuthState.Authenticated(user)
            }
            .onFailure { exception ->
                _authState.value = AuthState.Error(exception.message ?: "Facebook authentication failed")
            }
    }
    
    // Apple Sign In
    suspend fun signInWithApple() {
        _authState.value = AuthState.Loading
        
        authRepository.signInWithApple()
            .onSuccess { user ->
                _currentUser.value = user
                _authState.value = AuthState.Authenticated(user)
            }
            .onFailure { exception ->
                _authState.value = AuthState.Error(exception.message ?: "Apple authentication failed")
            }
    }
    
    // Sign Out
    fun signOut() {
        authRepository.signOut()
        _currentUser.value = null
        _authState.value = AuthState.Unauthenticated
    }
    
    // Reset Password
    suspend fun resetPassword(email: String): Result<Unit> {
        return authRepository.resetPassword(email)
    }
}

// Authentication state sealed class
sealed class AuthState {
    object Initial : AuthState()
    object Loading : AuthState()
    data class Authenticated(val user: FirebaseUser) : AuthState()
    object Unauthenticated : AuthState()
    data class Error(val message: String) : AuthState()
}
