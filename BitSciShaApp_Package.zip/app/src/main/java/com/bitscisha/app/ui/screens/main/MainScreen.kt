package com.bitscisha.app.ui.screens.main

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.bitscisha.app.R
import com.bitscisha.app.data.auth.AuthViewModel
import com.bitscisha.app.ui.components.CosmicBackground
import com.bitscisha.app.ui.navigation.NavDestinations
import kotlinx.coroutines.launch

data class BottomNavItem(
    val route: String,
    val title: String,
    val icon: ImageVector
)

@Composable
fun MainScreen(
    onNavigateToVideos: () -> Unit,
    onNavigateToTopics: () -> Unit,
    onNavigateToAbout: () -> Unit,
    onNavigateToCommunity: () -> Unit,
    onNavigateToAdmin: () -> Unit,
    authViewModel: AuthViewModel
) {
    val navController = rememberNavController()
    val scaffoldState = rememberScaffoldState()
    val coroutineScope = rememberCoroutineScope()
    
    val bottomNavItems = listOf(
        BottomNavItem(
            route = "videos",
            title = stringResource(R.string.nav_videos),
            icon = Icons.Default.VideoLibrary
        ),
        BottomNavItem(
            route = "topics",
            title = stringResource(R.string.nav_topics),
            icon = Icons.Default.Category
        ),
        BottomNavItem(
            route = "about",
            title = stringResource(R.string.nav_about),
            icon = Icons.Default.Info
        ),
        BottomNavItem(
            route = "community",
            title = stringResource(R.string.nav_community),
            icon = Icons.Default.People
        )
    )
    
    Scaffold(
        scaffoldState = scaffoldState,
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(8.dp)
                    ) {
                        Text(text = "BitSciSha")
                    }
                },
                actions = {
                    // Admin button (only shown if user is admin)
                    if (authViewModel.isUserAdmin()) {
                        IconButton(onClick = onNavigateToAdmin) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = "Admin Dashboard"
                            )
                        }
                    }
                    
                    // Shop button
                    IconButton(onClick = {
                        // Open Shopify store
                        // TODO: Implement WebView or external browser for shop
                    }) {
                        Icon(
                            imageVector = Icons.Default.ShoppingCart,
                            contentDescription = stringResource(R.string.nav_shop)
                        )
                    }
                    
                    // Profile/Logout menu
                    var showMenu by remember { mutableStateOf(false) }
                    
                    IconButton(onClick = { showMenu = true }) {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = "Account"
                        )
                    }
                    
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(onClick = {
                            showMenu = false
                            // TODO: Navigate to profile screen
                        }) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Profile")
                        }
                        
                        DropdownMenuItem(onClick = {
                            showMenu = false
                            authViewModel.signOut()
                            // Navigate back to login will be handled by auth state observer
                        }) {
                            Icon(
                                imageVector = Icons.Default.Logout,
                                contentDescription = null
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Sign Out")
                        }
                    }
                },
                backgroundColor = MaterialTheme.colors.primaryVariant
            )
        },
        bottomBar = {
            BottomNavigation(
                backgroundColor = MaterialTheme.colors.primaryVariant
            ) {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination
                
                bottomNavItems.forEach { item ->
                    BottomNavigationItem(
                        icon = { Icon(item.icon, contentDescription = item.title) },
                        label = { Text(item.title) },
                        selected = currentDestination?.hierarchy?.any { it.route == item.route } == true,
                        onClick = {
                            navController.navigate(item.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        selectedContentColor = MaterialTheme.colors.primary,
                        unselectedContentColor = MaterialTheme.colors.onSurface.copy(alpha = 0.6f)
                    )
                }
            }
        },
        drawerContent = null
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Background
            CosmicBackground()
            
            // Content
            NavHost(
                navController = navController,
                startDestination = "videos"
            ) {
                composable("videos") {
                    VideosScreen()
                }
                composable("topics") {
                    TopicsScreen()
                }
                composable("about") {
                    AboutScreen()
                }
                composable("community") {
                    CommunityScreen()
                }
            }
        }
    }
}
