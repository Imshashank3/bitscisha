package com.bitscisha.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.bitscisha.app.data.admin.AdminViewModel
import com.bitscisha.app.data.auth.AuthViewModel
import com.bitscisha.app.ui.screens.admin.AdminDashboardScreen
import com.bitscisha.app.ui.screens.admin.NotificationsScreen
import com.bitscisha.app.ui.screens.auth.LoginScreen
import com.bitscisha.app.ui.screens.auth.RegisterScreen
import com.bitscisha.app.ui.screens.main.AboutScreen
import com.bitscisha.app.ui.screens.main.CommunityScreen
import com.bitscisha.app.ui.screens.main.MainScreen
import com.bitscisha.app.ui.screens.main.TopicsScreen
import com.bitscisha.app.ui.screens.main.VideosScreen
import com.bitscisha.app.ui.screens.splash.SplashScreen

@Composable
fun BitSciShaNavHost(
    navController: NavHostController = rememberNavController(),
    startDestination: String = NavDestinations.SPLASH,
    authViewModel: AuthViewModel,
    adminViewModel: AdminViewModel
) {
    val actions = remember(navController) { NavActions(navController) }
    
    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        // Splash screen
        composable(NavDestinations.SPLASH) {
            SplashScreen(
                onNavigateToLogin = actions.navigateToLogin,
                onNavigateToMain = actions.navigateToMain
            )
        }
        
        // Authentication screens
        composable(NavDestinations.LOGIN) {
            LoginScreen(
                authViewModel = authViewModel,
                onNavigateToRegister = actions.navigateToRegister,
                onNavigateToMain = actions.navigateToMain
            )
        }
        
        composable(NavDestinations.REGISTER) {
            RegisterScreen(
                authViewModel = authViewModel,
                onNavigateToLogin = actions.navigateToLogin,
                onNavigateToMain = actions.navigateToMain
            )
        }
        
        // Main app screens
        composable(NavDestinations.MAIN) {
            MainScreen(
                onNavigateToVideos = actions.navigateToVideos,
                onNavigateToTopics = actions.navigateToTopics,
                onNavigateToAbout = actions.navigateToAbout,
                onNavigateToCommunity = actions.navigateToCommunity,
                onNavigateToAdmin = actions.navigateToAdmin,
                authViewModel = authViewModel
            )
        }
        
        composable(NavDestinations.VIDEOS) {
            VideosScreen()
        }
        
        composable(NavDestinations.TOPICS) {
            TopicsScreen()
        }
        
        composable(NavDestinations.ABOUT) {
            AboutScreen()
        }
        
        composable(NavDestinations.COMMUNITY) {
            CommunityScreen()
        }
        
        // Admin screens
        composable(NavDestinations.ADMIN) {
            AdminDashboardScreen(
                adminViewModel = adminViewModel,
                onNavigateToNotifications = actions.navigateToNotifications
            )
        }
        
        composable(NavDestinations.NOTIFICATIONS) {
            NotificationsScreen(
                adminViewModel = adminViewModel,
                onNavigateBack = actions.navigateUp
            )
        }
    }
}

object NavDestinations {
    const val SPLASH = "splash"
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val MAIN = "main"
    const val VIDEOS = "videos"
    const val TOPICS = "topics"
    const val ABOUT = "about"
    const val COMMUNITY = "community"
    const val ADMIN = "admin"
    const val NOTIFICATIONS = "notifications"
}

class NavActions(private val navController: NavHostController) {
    val navigateToLogin: () -> Unit = {
        navController.navigate(NavDestinations.LOGIN) {
            popUpTo(NavDestinations.SPLASH) { inclusive = true }
        }
    }
    
    val navigateToRegister: () -> Unit = {
        navController.navigate(NavDestinations.REGISTER)
    }
    
    val navigateToMain: () -> Unit = {
        navController.navigate(NavDestinations.MAIN) {
            popUpTo(NavDestinations.SPLASH) { inclusive = true }
        }
    }
    
    val navigateToVideos: () -> Unit = {
        navController.navigate(NavDestinations.VIDEOS)
    }
    
    val navigateToTopics: () -> Unit = {
        navController.navigate(NavDestinations.TOPICS)
    }
    
    val navigateToAbout: () -> Unit = {
        navController.navigate(NavDestinations.ABOUT)
    }
    
    val navigateToCommunity: () -> Unit = {
        navController.navigate(NavDestinations.COMMUNITY)
    }
    
    val navigateToAdmin: () -> Unit = {
        navController.navigate(NavDestinations.ADMIN)
    }
    
    val navigateToNotifications: () -> Unit = {
        navController.navigate(NavDestinations.NOTIFICATIONS)
    }
    
    val navigateUp: () -> Unit = {
        navController.navigateUp()
    }
}
