package com.bitscisha.app.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.bitscisha.app.ui.theme.PrimaryBg
import com.bitscisha.app.ui.theme.SecondaryBg

@Composable
fun CosmicBackground() {
    // Stars animation
    val infiniteTransition = rememberInfiniteTransition()
    val starsAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.7f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PrimaryBg)
    ) {
        // Radial gradient background
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            PrimaryBg,
                            SecondaryBg
                        )
                    )
                )
        )
        
        // Stars layer 1
        Box(
            modifier = Modifier
                .fillMaxSize()
                .alpha(starsAlpha)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = 0.05f)
                        )
                    )
                )
        )
        
        // Stars layer 2
        Box(
            modifier = Modifier
                .fillMaxSize()
                .alpha(starsAlpha * 0.7f)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = 0.03f)
                        ),
                        radius = 800f
                    )
                )
        )
        
        // Stars layer 3
        Box(
            modifier = Modifier
                .fillMaxSize()
                .alpha(starsAlpha * 0.5f)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.White.copy(alpha = 0.02f)
                        ),
                        radius = 1200f
                    )
                )
        )
    }
}
