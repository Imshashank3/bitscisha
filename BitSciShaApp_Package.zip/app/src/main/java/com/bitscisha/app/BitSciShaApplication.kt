package com.bitscisha.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class BitSciShaApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Initialize Firebase
        // Initialize other libraries as needed
    }
}
