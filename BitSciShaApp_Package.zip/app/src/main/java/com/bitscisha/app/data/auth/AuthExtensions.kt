package com.bitscisha.app.data.auth

import com.google.firebase.auth.FirebaseUser

/**
 * Extension function to check if the current user is an admin
 * This is a placeholder implementation - in a real app, this would check the user's role in Firestore
 */
fun AuthViewModel.isUserAdmin(): Boolean {
    // In a real implementation, this would check the user's role in Firestore
    // For testing purposes, we'll return true if the user is logged in
    return currentUser.value != null
}

/**
 * Extension function to check if the user is logged in
 */
fun AuthViewModel.isUserLoggedIn(): Boolean {
    return currentUser.value != null
}
