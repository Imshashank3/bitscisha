package com.bitscisha.app.data.admin

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collect
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AdminViewModel @Inject constructor(
    private val adminRepository: AdminRepository
) {
    // Admin state
    private val _adminState = MutableStateFlow<AdminState>(AdminState.Initial)
    val adminState: StateFlow<AdminState> = _adminState
    
    // Users list
    private val _users = MutableLiveData<List<UserData>>()
    val users: LiveData<List<UserData>> = _users
    
    // Notifications list
    private val _notifications = MutableLiveData<List<NotificationData>>()
    val notifications: LiveData<List<NotificationData>> = _notifications
    
    // Check if current user is admin
    suspend fun checkAdminStatus() {
        _adminState.value = AdminState.Loading
        
        val isAdmin = adminRepository.isCurrentUserAdmin()
        if (isAdmin) {
            _adminState.value = AdminState.IsAdmin
            loadUsers()
            loadNotifications()
        } else {
            _adminState.value = AdminState.NotAdmin
        }
    }
    
    // Load all users
    suspend fun loadUsers() {
        adminRepository.getAllUsers().collect { usersList ->
            _users.value = usersList
        }
    }
    
    // Load admin notifications
    suspend fun loadNotifications() {
        adminRepository.getAdminNotifications().collect { notificationsList ->
            _notifications.value = notificationsList
        }
    }
    
    // Reset user password
    suspend fun resetUserPassword(userEmail: String): Result<Unit> {
        return adminRepository.resetUserPassword(userEmail)
    }
    
    // Mark notification as read
    suspend fun markNotificationAsRead(notificationId: String): Result<Unit> {
        val result = adminRepository.markNotificationAsRead(notificationId)
        
        if (result.isSuccess) {
            // Update local notifications list
            _notifications.value = _notifications.value?.map { notification ->
                if (notification.id == notificationId) {
                    notification.copy(read = true)
                } else {
                    notification
                }
            }
        }
        
        return result
    }
    
    // Delete user account
    suspend fun deleteUserAccount(userId: String): Result<Unit> {
        val result = adminRepository.deleteUserAccount(userId)
        
        if (result.isSuccess) {
            // Update local users list
            _users.value = _users.value?.filter { it.uid != userId }
        }
        
        return result
    }
    
    // Update user role
    suspend fun updateUserRole(userId: String, newRole: String): Result<Unit> {
        val result = adminRepository.updateUserRole(userId, newRole)
        
        if (result.isSuccess) {
            // Update local users list
            _users.value = _users.value?.map { user ->
                if (user.uid == userId) {
                    user.copy(role = newRole)
                } else {
                    user
                }
            }
        }
        
        return result
    }
}

// Admin state sealed class
sealed class AdminState {
    object Initial : AdminState()
    object Loading : AdminState()
    object IsAdmin : AdminState()
    object NotAdmin : AdminState()
    data class Error(val message: String) : AdminState()
}
