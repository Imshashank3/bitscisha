package com.bitscisha.app.ui.screens.main

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.bitscisha.app.R
import com.bitscisha.app.ui.components.CosmicBackground
import com.bitscisha.app.ui.theme.PrimaryAccent

@Composable
fun AboutScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colors.background)
    ) {
        // Background
        CosmicBackground()
        
        // Content
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Text(
                    text = stringResource(R.string.about_bitscisha),
                    style = MaterialTheme.typography.h4,
                    color = MaterialTheme.colors.onBackground
                )
                
                Spacer(modifier = Modifier.height(24.dp))
                
                // About content
                AboutContent()
                
                Spacer(modifier = Modifier.height(32.dp))
                
                // Stats
                StatsRow()
                
                Spacer(modifier = Modifier.height(24.dp))
                
                // Learn more button
                OutlinedButton(
                    onClick = { /* TODO: Navigate to learn more URL */ },
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = PrimaryAccent
                    )
                ) {
                    Text(text = stringResource(R.string.learn_more))
                }
                
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

@Composable
fun AboutContent() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        backgroundColor = MaterialTheme.colors.surface.copy(alpha = 0.8f),
        elevation = 4.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // About image
            Image(
                painter = painterResource(id = R.drawable.about_illustration),
                contentDescription = "About BitSciSha",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(8.dp)),
                contentScale = ContentScale.Fit
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // About text
            Text(
                text = "At BitSciSha, we put biographies and documentaries front and center—because every discovery, from penicillin to quantum AI, has a storyteller at its heart.",
                style = MaterialTheme.typography.body1,
                textAlign = TextAlign.Start
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Text(
                text = "Here you'll embark on lyrical journeys through swirling galaxies—nebulae blooming like cosmic flowers, spiral arms pirouetting in starlight (no boarding pass required)—and delve into terrestrial bodies, from cratered moons and rust‑hued Martian canyons to Earth's own ocean‑kissed shores and mountain peaks kissed by clouds.",
                style = MaterialTheme.typography.body1,
                textAlign = TextAlign.Start
            )
            
            Spacer(modifier = Modifier.height(12.dp))
            
            Text(
                text = "All of this unfolds in stunning 2D and 3D animation, powered by science, space exploration, and cutting‑edge AI, turning each life story and documentary deep‑dive into a living, breathing adventure. Join the voyage: let's chart the human spirit among the stars.",
                style = MaterialTheme.typography.body1,
                textAlign = TextAlign.Start
            )
        }
    }
}

@Composable
fun StatsRow() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        StatItem(value = "500+", label = stringResource(R.string.subscribers))
        StatItem(value = "3", label = stringResource(R.string.videos))
        StatItem(value = "∞", label = stringResource(R.string.potential))
        StatItem(value = "10K", label = stringResource(R.string.mission))
    }
}

@Composable
fun StatItem(value: String, label: String) {
    Card(
        modifier = Modifier
            .width(80.dp)
            .height(80.dp),
        shape = RoundedCornerShape(8.dp),
        backgroundColor = MaterialTheme.colors.surface.copy(alpha = 0.8f),
        elevation = 4.dp
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.h5,
                color = PrimaryAccent
            )
            
            Text(
                text = label,
                style = MaterialTheme.typography.caption,
                color = MaterialTheme.colors.onSurface.copy(alpha = 0.7f)
            )
        }
    }
}
