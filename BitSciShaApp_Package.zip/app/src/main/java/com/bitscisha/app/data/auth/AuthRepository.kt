package com.bitscisha.app.data.auth

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.FacebookAuthProvider
import com.google.firebase.auth.OAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AuthRepository @Inject constructor(
    private val firebaseAuth: FirebaseAuth,
    private val firestore: FirebaseFirestore
) {
    // Current user
    val currentUser: FirebaseUser?
        get() = firebaseAuth.currentUser
    
    // Check if user is logged in
    fun isUserLoggedIn(): Boolean {
        return currentUser != null
    }
    
    // Email/Password Sign In
    suspend fun signInWithEmailPassword(email: String, password: String): Result<FirebaseUser> {
        return try {
            val authResult = firebaseAuth.signInWithEmailAndPassword(email, password).await()
            authResult.user?.let {
                Result.success(it)
            } ?: Result.failure(Exception("Authentication failed"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    // Email/Password Registration
    suspend fun registerWithEmailPassword(email: String, password: String, name: String): Result<FirebaseUser> {
        return try {
            val authResult = firebaseAuth.createUserWithEmailAndPassword(email, password).await()
            authResult.user?.let { user ->
                // Create user profile in Firestore
                val userProfile = hashMapOf(
                    "uid" to user.uid,
                    "email" to email,
                    "name" to name,
                    "createdAt" to System.currentTimeMillis(),
                    "role" to "user"
                )
                
                // Save user profile
                firestore.collection("users").document(user.uid).set(userProfile).await()
                
                // Send notification email to admin
                sendRegistrationNotification(user.uid, email, name)
                
                Result.success(user)
            } ?: Result.failure(Exception("Registration failed"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    // Google Sign In
    suspend fun signInWithGoogle(idToken: String): Result<FirebaseUser> {
        return try {
            val credential = GoogleAuthProvider.getCredential(idToken, null)
            val authResult = firebaseAuth.signInWithCredential(credential).await()
            
            authResult.user?.let { user ->
                // Check if this is a new user
                val isNewUser = authResult.additionalUserInfo?.isNewUser ?: false
                
                if (isNewUser) {
                    // Create user profile in Firestore
                    val userProfile = hashMapOf(
                        "uid" to user.uid,
                        "email" to user.email,
                        "name" to (user.displayName ?: ""),
                        "photoUrl" to (user.photoUrl?.toString() ?: ""),
                        "createdAt" to System.currentTimeMillis(),
                        "role" to "user"
                    )
                    
                    // Save user profile
                    firestore.collection("users").document(user.uid).set(userProfile).await()
                    
                    // Send notification email to admin
                    sendRegistrationNotification(user.uid, user.email ?: "", user.displayName ?: "")
                }
                
                Result.success(user)
            } ?: Result.failure(Exception("Google authentication failed"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    // Facebook Sign In
    suspend fun signInWithFacebook(token: String): Result<FirebaseUser> {
        return try {
            val credential = FacebookAuthProvider.getCredential(token)
            val authResult = firebaseAuth.signInWithCredential(credential).await()
            
            authResult.user?.let { user ->
                // Check if this is a new user
                val isNewUser = authResult.additionalUserInfo?.isNewUser ?: false
                
                if (isNewUser) {
                    // Create user profile in Firestore
                    val userProfile = hashMapOf(
                        "uid" to user.uid,
                        "email" to user.email,
                        "name" to (user.displayName ?: ""),
                        "photoUrl" to (user.photoUrl?.toString() ?: ""),
                        "createdAt" to System.currentTimeMillis(),
                        "role" to "user"
                    )
                    
                    // Save user profile
                    firestore.collection("users").document(user.uid).set(userProfile).await()
                    
                    // Send notification email to admin
                    sendRegistrationNotification(user.uid, user.email ?: "", user.displayName ?: "")
                }
                
                Result.success(user)
            } ?: Result.failure(Exception("Facebook authentication failed"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    // Apple Sign In
    suspend fun signInWithApple(): Result<FirebaseUser> {
        return try {
            val provider = OAuthProvider.newBuilder("apple.com")
            provider.scopes = listOf("email", "name")
            
            val authResult = firebaseAuth.startActivityForSignInWithProvider(/* activity */ null, provider.build()).await()
            
            authResult.user?.let { user ->
                // Check if this is a new user
                val isNewUser = authResult.additionalUserInfo?.isNewUser ?: false
                
                if (isNewUser) {
                    // Create user profile in Firestore
                    val userProfile = hashMapOf(
                        "uid" to user.uid,
                        "email" to user.email,
                        "name" to (user.displayName ?: ""),
                        "photoUrl" to (user.photoUrl?.toString() ?: ""),
                        "createdAt" to System.currentTimeMillis(),
                        "role" to "user"
                    )
                    
                    // Save user profile
                    firestore.collection("users").document(user.uid).set(userProfile).await()
                    
                    // Send notification email to admin
                    sendRegistrationNotification(user.uid, user.email ?: "", user.displayName ?: "")
                }
                
                Result.success(user)
            } ?: Result.failure(Exception("Apple authentication failed"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    // Sign Out
    fun signOut() {
        firebaseAuth.signOut()
    }
    
    // Reset Password
    suspend fun resetPassword(email: String): Result<Unit> {
        return try {
            firebaseAuth.sendPasswordResetEmail(email).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    // Send registration notification to admin
    private suspend fun sendRegistrationNotification(userId: String, email: String, name: String) {
        try {
            // Create notification in Firestore
            val notification = hashMapOf(
                "type" to "new_user",
                "userId" to userId,
                "userEmail" to email,
                "userName" to name,
                "timestamp" to System.currentTimeMillis(),
                "read" to false
            )
            
            firestore.collection("admin_notifications").add(notification).await()
            
            // TODO: Implement Cloud Function to send email to bitscisha.com
        } catch (e: Exception) {
            // Log error but don't fail the registration process
            println("Failed to send registration notification: ${e.message}")
        }
    }
}
