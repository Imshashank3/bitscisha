package com.bitscisha.app.ui.screens.main

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.bitscisha.app.R
import com.bitscisha.app.ui.components.CosmicBackground
import com.bitscisha.app.ui.theme.*

@Composable
fun TopicsScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colors.background)
    ) {
        // Background
        CosmicBackground()
        
        // Content
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            item {
                Text(
                    text = stringResource(R.string.real_time_topics),
                    style = MaterialTheme.typography.h4,
                    color = MaterialTheme.colors.onBackground
                )
                
                Spacer(modifier = Modifier.height(24.dp))
                
                // Topics grid
                TopicsGrid()
            }
        }
    }
}

@Composable
fun TopicsGrid() {
    val topics = listOf(
        TopicItem(
            id = "1",
            title = stringResource(R.string.space_astronomy),
            description = "Explore the cosmos, from black holes to the edge of the observable universe.",
            iconResId = R.drawable.ic_space,
            accentColor = PrimaryAccent
        ),
        TopicItem(
            id = "2",
            title = stringResource(R.string.documentaries_stories),
            description = "Discover the incredible complexity of life and the human body.",
            iconResId = R.drawable.ic_documentaries,
            accentColor = SecondaryAccent
        ),
        TopicItem(
            id = "3",
            title = stringResource(R.string.physics_technology),
            description = "Understand the fundamental laws that govern our reality.",
            iconResId = R.drawable.ic_physics,
            accentColor = TertiaryAccent
        ),
        TopicItem(
            id = "4",
            title = stringResource(R.string.geopolitics_politics),
            description = "Contemplate the big questions about on going world and Indian issues.",
            iconResId = R.drawable.ic_geopolitics,
            accentColor = QuaternaryAccent
        ),
        TopicItem(
            id = "5",
            title = stringResource(R.string.society_philosophy),
            description = "Examine the challenges and potential of human civilization.",
            iconResId = R.drawable.ic_society,
            accentColor = Color(0xFF4CAF50)
        ),
        TopicItem(
            id = "6",
            title = stringResource(R.string.speculative_scenarios),
            description = "Imagine \"what if\" situations with scientific accuracy.",
            iconResId = R.drawable.ic_speculative,
            accentColor = Color(0xFFE91E63)
        )
    )
    
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(topics) { topic ->
            TopicCard(topic = topic)
        }
    }
}

@Composable
fun TopicCard(topic: TopicItem) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { /* TODO: Navigate to topic detail */ },
        shape = RoundedCornerShape(12.dp),
        backgroundColor = SecondaryBg.copy(alpha = 0.7f),
        elevation = 4.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.Start
        ) {
            // Topic icon
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(CircleShape)
                    .background(topic.accentColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painter = painterResource(id = topic.iconResId),
                    contentDescription = topic.title,
                    tint = Color.White,
                    modifier = Modifier.size(32.dp)
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Topic title
            Text(
                text = topic.title,
                style = MaterialTheme.typography.h6,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Topic description
            Text(
                text = topic.description,
                style = MaterialTheme.typography.body2,
                color = MaterialTheme.colors.onBackground.copy(alpha = 0.7f),
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Explore button
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.explore),
                    style = MaterialTheme.typography.button.copy(
                        color = topic.accentColor,
                        fontWeight = FontWeight.SemiBold
                    )
                )
                
                Spacer(modifier = Modifier.width(4.dp))
                
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = null,
                    tint = topic.accentColor,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

data class TopicItem(
    val id: String,
    val title: String,
    val description: String,
    val iconResId: Int,
    val accentColor: Color
)
