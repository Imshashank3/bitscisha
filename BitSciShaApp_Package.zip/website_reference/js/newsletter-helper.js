// Newsletter AJAX submission helper script
document.addEventListener('DOMContentLoaded', function() {
    const newsletterForm = document.querySelector('.newsletter-form');
    const formStatusMessage = document.createElement('div');
    formStatusMessage.className = 'form-status-message';
    formStatusMessage.style.marginTop = '10px';
    formStatusMessage.style.display = 'none';
    
    if (newsletterForm) {
        // Add the status message element after the form
        newsletterForm.appendChild(formStatusMessage);
        
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault(); // Prevent default form submission
            
            const formData = new FormData(this);
            const formObject = {};
            formData.forEach((value, key) => {
                formObject[key] = value;
            });
            
            // Show loading message
            formStatusMessage.style.display = 'block';
            formStatusMessage.style.color = '#00e5ff';
            formStatusMessage.textContent = 'Subscribing...';
            
            // Send AJAX request to FormSubmit
            fetch(this.action, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(formObject)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Success message
                    formStatusMessage.style.color = '#00e5ff';
                    formStatusMessage.textContent = 'Thank you for subscribing!';
                    newsletterForm.reset();
                    
                    // Log for debugging
                    console.log('Newsletter form submitted successfully - notification sent to bitscisha@gmail.com');
                    
                    // Hide message after 3 seconds
                    setTimeout(() => {
                        formStatusMessage.style.display = 'none';
                    }, 3000);
                } else {
                    // Error message
                    formStatusMessage.style.color = '#ff3366';
                    formStatusMessage.textContent = 'Something went wrong. Please try again.';
                    
                    console.error('Form submission error:', data);
                }
            })
            .catch(error => {
                // Error message
                formStatusMessage.style.color = '#ff3366';
                formStatusMessage.textContent = 'Something went wrong. Please try again.';
                
                console.error('Form submission error:', error);
            });
        });
    }
});
