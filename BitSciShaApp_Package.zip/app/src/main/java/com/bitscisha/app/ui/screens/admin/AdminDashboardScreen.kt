package com.bitscisha.app.ui.screens.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.bitscisha.app.data.admin.AdminViewModel
import com.bitscisha.app.data.admin.UserData
import com.bitscisha.app.ui.components.CosmicBackground
import com.bitscisha.app.ui.theme.PrimaryAccent
import com.bitscisha.app.ui.theme.SecondaryAccent
import com.bitscisha.app.ui.theme.SecondaryBg
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun AdminDashboardScreen(
    adminViewModel: AdminViewModel,
    onNavigateToNotifications: () -> Unit
) {
    val users by adminViewModel.users.collectAsState(initial = emptyList())
    val unreadNotifications by adminViewModel.notifications.collectAsState(initial = emptyList())
    val unreadCount = unreadNotifications.count { !it.read }
    
    LaunchedEffect(key1 = true) {
        adminViewModel.checkAdminStatus()
        adminViewModel.loadUsers()
        adminViewModel.loadNotifications()
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colors.background)
    ) {
        // Background
        CosmicBackground()
        
        // Content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Admin Dashboard",
                    style = MaterialTheme.typography.h4,
                    color = MaterialTheme.colors.onBackground
                )
                
                // Notifications button
                IconButton(
                    onClick = onNavigateToNotifications,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(SecondaryBg.copy(alpha = 0.8f))
                ) {
                    Box {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Notifications",
                            tint = MaterialTheme.colors.onBackground
                        )
                        
                        if (unreadCount > 0) {
                            Box(
                                modifier = Modifier
                                    .size(16.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(SecondaryAccent)
                                    .align(Alignment.TopEnd),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (unreadCount > 9) "9+" else unreadCount.toString(),
                                    style = MaterialTheme.typography.caption.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                )
                            }
                        }
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            // User management section
            Text(
                text = "User Management",
                style = MaterialTheme.typography.h5,
                color = MaterialTheme.colors.onBackground
            )
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Users list
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                backgroundColor = SecondaryBg.copy(alpha = 0.8f),
                elevation = 4.dp
            ) {
                if (users.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = PrimaryAccent)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 500.dp)
                    ) {
                        items(users) { user ->
                            UserListItem(
                                user = user,
                                onResetPassword = { adminViewModel.resetUserPassword(user.email) },
                                onDeleteUser = { adminViewModel.deleteUserAccount(user.uid) },
                                onUpdateRole = { newRole -> adminViewModel.updateUserRole(user.uid, newRole) }
                            )
                            
                            Divider(color = MaterialTheme.colors.onSurface.copy(alpha = 0.1f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun UserListItem(
    user: UserData,
    onResetPassword: () -> Unit,
    onDeleteUser: () -> Unit,
    onUpdateRole: (String) -> Unit
) {
    var showOptions by remember { mutableStateOf(false) }
    var showRoleDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmation by remember { mutableStateOf(false) }
    var showResetConfirmation by remember { mutableStateOf(false) }
    
    val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
    val createdDate = dateFormat.format(Date(user.createdAt))
    
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // User info
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = user.name,
                    style = MaterialTheme.typography.subtitle1.copy(
                        fontWeight = FontWeight.Bold
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = user.email,
                    style = MaterialTheme.typography.body2,
                    color = MaterialTheme.colors.onBackground.copy(alpha = 0.7f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Joined: $createdDate",
                        style = MaterialTheme.typography.caption,
                        color = MaterialTheme.colors.onBackground.copy(alpha = 0.5f)
                    )
                    
                    Spacer(modifier = Modifier.width(8.dp))
                    
                    Chip(
                        text = user.role,
                        color = if (user.role == "admin") SecondaryAccent else PrimaryAccent
                    )
                }
            }
            
            // Options button
            IconButton(
                onClick = { showOptions = !showOptions }
            ) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Options",
                    tint = MaterialTheme.colors.onBackground
                )
            }
        }
        
        // Options menu
        if (showOptions) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colors.surface)
            ) {
                OptionItem(
                    icon = Icons.Default.VpnKey,
                    text = "Reset Password",
                    onClick = { 
                        showOptions = false
                        showResetConfirmation = true
                    }
                )
                
                OptionItem(
                    icon = Icons.Default.SupervisorAccount,
                    text = "Change Role",
                    onClick = { 
                        showOptions = false
                        showRoleDialog = true
                    }
                )
                
                OptionItem(
                    icon = Icons.Default.Delete,
                    text = "Delete User",
                    onClick = { 
                        showOptions = false
                        showDeleteConfirmation = true
                    },
                    textColor = Color.Red
                )
            }
        }
    }
    
    // Role selection dialog
    if (showRoleDialog) {
        AlertDialog(
            onDismissRequest = { showRoleDialog = false },
            title = { Text("Change User Role") },
            text = { 
                Column {
                    Text("Select a role for ${user.name}")
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    val roles = listOf("user", "admin")
                    var selectedRole by remember { mutableStateOf(user.role) }
                    
                    roles.forEach { role ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                                .clickable { selectedRole = role },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = selectedRole == role,
                                onClick = { selectedRole = role }
                            )
                            
                            Spacer(modifier = Modifier.width(8.dp))
                            
                            Text(
                                text = role.capitalize(),
                                style = MaterialTheme.typography.body1
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onUpdateRole(selectedRole)
                        showRoleDialog = false
                    }
                ) {
                    Text("Confirm")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showRoleDialog = false }
                ) {
                    Text("Cancel")
                }
            }
        )
    }
    
    // Delete confirmation dialog
    if (showDeleteConfirmation) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmation = false },
            title = { Text("Delete User") },
            text = { Text("Are you sure you want to delete ${user.name}? This action cannot be undone.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteUser()
                        showDeleteConfirmation = false
                    }
                ) {
                    Text("Delete", color = Color.Red)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showDeleteConfirmation = false }
                ) {
                    Text("Cancel")
                }
            }
        )
    }
    
    // Reset password confirmation dialog
    if (showResetConfirmation) {
        AlertDialog(
            onDismissRequest = { showResetConfirmation = false },
            title = { Text("Reset Password") },
            text = { Text("Send password reset email to ${user.email}?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onResetPassword()
                        showResetConfirmation = false
                    }
                ) {
                    Text("Send")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showResetConfirmation = false }
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun OptionItem(
    icon: ImageVector,
    text: String,
    onClick: () -> Unit,
    textColor: Color = MaterialTheme.colors.onSurface
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = textColor
        )
        
        Spacer(modifier = Modifier.width(16.dp))
        
        Text(
            text = text,
            style = MaterialTheme.typography.body1,
            color = textColor
        )
    }
}

@Composable
fun Chip(
    text: String,
    color: Color
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.2f))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text.capitalize(),
            style = MaterialTheme.typography.caption.copy(
                color = color,
                fontWeight = FontWeight.Bold
            )
        )
    }
}

private fun String.capitalize(): String {
    return this.replaceFirstChar { 
        if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() 
    }
}
