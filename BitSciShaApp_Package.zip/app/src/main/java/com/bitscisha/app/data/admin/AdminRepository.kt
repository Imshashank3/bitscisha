package com.bitscisha.app.data.admin

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.functions.FirebaseFunctions
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AdminRepository @Inject constructor(
    private val firebaseAuth: FirebaseAuth,
    private val firestore: FirebaseFirestore,
    private val functions: FirebaseFunctions
) {
    // Check if current user is admin
    suspend fun isCurrentUserAdmin(): Boolean {
        val currentUser = firebaseAuth.currentUser ?: return false
        
        return try {
            val userDoc = firestore.collection("users").document(currentUser.uid).get().await()
            val role = userDoc.getString("role") ?: "user"
            role == "admin"
        } catch (e: Exception) {
            false
        }
    }
    
    // Get all users
    suspend fun getAllUsers(): Flow<List<UserData>> = flow {
        try {
            val snapshot = firestore.collection("users")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .get()
                .await()
            
            val users = snapshot.documents.mapNotNull { doc ->
                val uid = doc.getString("uid") ?: return@mapNotNull null
                val email = doc.getString("email") ?: ""
                val name = doc.getString("name") ?: ""
                val photoUrl = doc.getString("photoUrl") ?: ""
                val createdAt = doc.getLong("createdAt") ?: 0
                val role = doc.getString("role") ?: "user"
                
                UserData(
                    uid = uid,
                    email = email,
                    name = name,
                    photoUrl = photoUrl,
                    createdAt = createdAt,
                    role = role
                )
            }
            
            emit(users)
        } catch (e: Exception) {
            emit(emptyList())
        }
    }
    
    // Reset user password
    suspend fun resetUserPassword(userEmail: String): Result<Unit> {
        return try {
            // Call Firebase Cloud Function to send password reset email
            val data = hashMapOf(
                "email" to userEmail
            )
            
            functions.getHttpsCallable("resetUserPassword")
                .call(data)
                .await()
            
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    // Get admin notifications
    suspend fun getAdminNotifications(): Flow<List<NotificationData>> = flow {
        try {
            val snapshot = firestore.collection("admin_notifications")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .get()
                .await()
            
            val notifications = snapshot.documents.mapNotNull { doc ->
                val id = doc.id
                val type = doc.getString("type") ?: return@mapNotNull null
                val userId = doc.getString("userId") ?: ""
                val userEmail = doc.getString("userEmail") ?: ""
                val userName = doc.getString("userName") ?: ""
                val timestamp = doc.getLong("timestamp") ?: 0
                val read = doc.getBoolean("read") ?: false
                
                NotificationData(
                    id = id,
                    type = type,
                    userId = userId,
                    userEmail = userEmail,
                    userName = userName,
                    timestamp = timestamp,
                    read = read
                )
            }
            
            emit(notifications)
        } catch (e: Exception) {
            emit(emptyList())
        }
    }
    
    // Mark notification as read
    suspend fun markNotificationAsRead(notificationId: String): Result<Unit> {
        return try {
            firestore.collection("admin_notifications")
                .document(notificationId)
                .update("read", true)
                .await()
            
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    // Delete user account
    suspend fun deleteUserAccount(userId: String): Result<Unit> {
        return try {
            // Call Firebase Cloud Function to delete user
            val data = hashMapOf(
                "userId" to userId
            )
            
            functions.getHttpsCallable("deleteUserAccount")
                .call(data)
                .await()
            
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    // Update user role
    suspend fun updateUserRole(userId: String, newRole: String): Result<Unit> {
        return try {
            firestore.collection("users")
                .document(userId)
                .update("role", newRole)
                .await()
            
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

data class UserData(
    val uid: String,
    val email: String,
    val name: String,
    val photoUrl: String,
    val createdAt: Long,
    val role: String
)

data class NotificationData(
    val id: String,
    val type: String,
    val userId: String,
    val userEmail: String,
    val userName: String,
    val timestamp: Long,
    val read: Boolean
)
